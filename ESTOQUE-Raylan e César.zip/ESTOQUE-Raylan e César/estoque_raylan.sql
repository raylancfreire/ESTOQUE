-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Jun-2023 às 19:36
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `estoque_raylan`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `chaves`
--

CREATE TABLE `chaves` (
  `id_chave` int(11) NOT NULL,
  `numero_chave` int(30) DEFAULT NULL,
  `sala_chave` varchar(255) DEFAULT NULL,
  `status_chave` varchar(255) DEFAULT NULL,
  `solicitador_chave` varchar(255) DEFAULT NULL,
  `contato_solicitador_chave` bigint(11) DEFAULT NULL,
  `data_solicitacao_chave` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `chaves`
--

INSERT INTO `chaves` (`id_chave`, `numero_chave`, `sala_chave`, `status_chave`, `solicitador_chave`, `contato_solicitador_chave`, `data_solicitacao_chave`) VALUES
(1, 1442, 'Pneumática', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:53:51'),
(2, 2421, 'Mecatrônica', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:54:33'),
(3, 8910, 'Cybersegurança', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:54:58'),
(4, 1281, 'Cabeamento', 'EMPRESTADA', 'Renisson', 27995263333, '2023-06-30 16:55:10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `itens_tb`
--

CREATE TABLE `itens_tb` (
  `id_item` int(11) NOT NULL,
  `nome_item` varchar(255) NOT NULL,
  `qtd_item` int(11) NOT NULL,
  `cat_item` varchar(255) NOT NULL,
  `local_item` varchar(255) NOT NULL,
  `status_item` varchar(255) NOT NULL,
  `solicitador_item` varchar(255) DEFAULT NULL,
  `contato_solicitador_item` bigint(11) DEFAULT NULL,
  `data_solicitacao_item` timestamp NULL DEFAULT current_timestamp(),
  `data_item` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `itens_tb`
--

INSERT INTO `itens_tb` (`id_item`, `nome_item`, `qtd_item`, `cat_item`, `local_item`, `status_item`, `solicitador_item`, `contato_solicitador_item`, `data_solicitacao_item`, `data_item`) VALUES
(1, 'Papel Higiênico', 9, 'Uso Único', 'Fila 2A', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:47:56', '2023-06-30 16:47:56'),
(2, 'Caneta', 15, 'Uso Único', 'Fila 2B', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:48:20', '2023-06-30 16:48:20'),
(3, 'Chamex', 5, 'Uso Único', 'Fila 2A', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:48:35', '2023-06-30 16:48:35'),
(4, 'Fios', 3, 'Uso Único', 'Fila 2A', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:48:52', '2023-06-30 16:48:52'),
(5, 'Cola', 17, 'Uso Único', 'Fila 2B', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:49:05', '2023-06-30 16:49:05'),
(6, 'Mouse', 1, 'Patrimônio', 'Fila 4B', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:49:25', '2023-06-30 16:49:25'),
(7, 'Teclado', 1, 'Patrimônio', 'Fila', 'EMPRESTADO', 'Ramon', 27989899999, '2023-06-30 16:49:39', '2023-06-30 16:49:39'),
(8, 'Martelo', 1, 'Patrimônio', 'Fila 4B', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:50:55', '2023-06-30 16:50:55'),
(9, 'Maquita', 1, 'Patrimônio', 'Fila 3C', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:51:08', '2023-06-30 16:51:08'),
(10, 'Pregos', 46, 'Uso Único', 'Fila', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:51:23', '2023-06-30 16:51:23'),
(11, 'Parafuso', 4, 'Uso Único', 'Fila 2B', 'DISPONÍVEL', NULL, NULL, '2023-06-30 16:51:36', '2023-06-30 16:51:36'),
(15, 'Placa', 5, 'Uso Único', 'Fila 4B', 'DISPONÍVEL', NULL, NULL, '2023-06-30 17:30:35', '2023-06-30 17:30:35');

-- --------------------------------------------------------

--
-- Estrutura da tabela `relatorios_tb`
--

CREATE TABLE `relatorios_tb` (
  `id_relatorio` int(11) NOT NULL,
  `id_item` int(11) DEFAULT NULL,
  `nome_item` varchar(255) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `retirante_item` varchar(255) DEFAULT NULL,
  `contato_retirante_item` bigint(11) DEFAULT NULL,
  `data_retirada_item` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `relatorios_tb`
--

INSERT INTO `relatorios_tb` (`id_relatorio`, `id_item`, `nome_item`, `quantidade`, `retirante_item`, `contato_retirante_item`, `data_retirada_item`) VALUES
(1, 10, 'Pregos', 4, 'Jonas', 27956238174, '2023-06-30 17:11:56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `login` varchar(30) NOT NULL,
  `senha` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `nome`, `categoria`, `login`, `senha`) VALUES
(1, 'admin@gmail.com', 'admin', 'ADMIN', 'admin', '123'),
(2, 'fun@gmail.com', 'funcionario', 'FUNCIONARIO', 'fun', '123'),
(3, 'ins@gmail.com', 'inspetor', 'INSPETOR', 'ins', '123');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `chaves`
--
ALTER TABLE `chaves`
  ADD PRIMARY KEY (`id_chave`),
  ADD UNIQUE KEY `numero_chave` (`numero_chave`);

--
-- Índices para tabela `itens_tb`
--
ALTER TABLE `itens_tb`
  ADD PRIMARY KEY (`id_item`);

--
-- Índices para tabela `relatorios_tb`
--
ALTER TABLE `relatorios_tb`
  ADD PRIMARY KEY (`id_relatorio`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `chaves`
--
ALTER TABLE `chaves`
  MODIFY `id_chave` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `itens_tb`
--
ALTER TABLE `itens_tb`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `relatorios_tb`
--
ALTER TABLE `relatorios_tb`
  MODIFY `id_relatorio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
