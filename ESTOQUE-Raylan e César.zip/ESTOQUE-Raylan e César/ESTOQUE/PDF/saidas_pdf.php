<?php
require("../conn.php");
require("../protected.php");
require("biblioteca/fpdf.php");

// Dados da tabela
$tabela = $pdo->prepare("SELECT id_relatorio, nome_item, quantidade, retirante_item, data_retirada_item FROM relatorios_tb");
$tabela->execute();
$rowTabela = $tabela->fetchAll(PDO::FETCH_ASSOC);

// Cria uma instância do objeto FPDF
$pdf = new FPDF();

// Define o título do documento
$pdf->SetTitle('Saidas');

// Adiciona uma página ao PDF
$pdf->AddPage();

// Define a fonte padrão
$pdf->SetFont('Arial', 'B', 14);

// Define a largura das colunas da tabela
$colWidth = 35;
$pdf->SetFillColor(200, 200, 200);
$pdf->Cell($colWidth, 10, 'ID Relatorio', 1, 0, 'C', true);
$pdf->Cell($colWidth, 10, 'Nome Item', 1, 0, 'C', true);
$pdf->Cell($colWidth, 10, 'Qtd. Retirada', 1, 0, 'C', true);
$pdf->Cell($colWidth, 10, 'Retirante', 1, 0, 'C', true);
$pdf->Cell($colWidth + 10, 10, 'Data e Hora', 1, 1, 'C', true);

// Define a fonte para os dados da tabela
$pdf->SetFont('Arial', '', 12);

// Percorre os dados da tabela
foreach ($rowTabela as $linha) {
    $idRelatorio = utf8_decode($linha['id_relatorio']);
    $nome = utf8_decode($linha['nome_item']);
    $qtdItem = utf8_decode($linha['quantidade']);
    $retirante = utf8_decode($linha['retirante_item']);
    $data = utf8_decode($linha['data_retirada_item']);

    // Verifica se a célula excede a largura da página
    if ($pdf->GetX() + $colWidth > $pdf->GetPageWidth()) {
        $pdf->AddPage();
        $pdf->Cell($colWidth, 10, 'ID Relatorio', 1, 0, 'C', true);
        $pdf->Cell($colWidth, 10, 'Nome Item', 1, 0, 'C', true);
        $pdf->Cell($colWidth, 10, 'Quantidade Retirada', 1, 0, 'C', true);
        $pdf->Cell($colWidth, 10, 'Retirante', 1, 0, 'C', true);
        $pdf->Cell($colWidth + 10, 10, 'Data e Hora', 1, 1, 'C', true);
    }

    // Adiciona uma célula para cada campo
    $pdf->Cell($colWidth, 10, $idRelatorio, 1, 0, 'C');
    $pdf->Cell($colWidth, 10, $nome, 1, 0, 'C');
    $pdf->Cell($colWidth, 10, $qtdItem, 1, 0, 'C');
    $pdf->Cell($colWidth, 10, $retirante, 1, 0, 'C');
    $pdf->Cell($colWidth + 10, 10, $data, 1, 1, 'C');
}

// Define o nome do arquivo com a data de download
$fileName = 'Saidas' . date('Y-m-d') . '.pdf';

// Define o cabeçalho para download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $fileName . '"');

// Envia o PDF para o navegador
$pdf->Output('D', $fileName);
