<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    
</body>
</html>
<?php
    require('../conn.php');

    $id_chave = $_POST['id_chave'];
    $solicitador_chave = $_POST['solicitador_chave'];
    $contato_solicitador_chave = $_POST['contato_solicitador_chave'];
    $status_chave = $_POST['status_chave'];

    if(empty($id_chave) || empty($solicitador_chave) || empty($contato_solicitador_chave) || empty($status_chave)){
        echo "Os valores não podem ser vazios";
    }else{
        $emprestar = $pdo->prepare("UPDATE chaves set 
        id_chave = :id_chave, 
        solicitador_chave = :solicitador_chave,
        contato_solicitador_chave = :contato_solicitador_chave,
        status_chave = :status_chave
        WHERE 
        id_chave = :id_chave;");
    

    $emprestar->execute(array(
        ':id_chave' => $id_chave,
        ':solicitador_chave'=> $solicitador_chave,
        ':contato_solicitador_chave'=> $contato_solicitador_chave,
        ':status_chave'=> $status_chave
    ));

    echo "<script>
    Swal.fire({
        icon: 'success',
        title: '',
        text: 'Chave emprestada com sucesso!',
        confirmButtonText: 'OK',
        onClose: function() {
            window.location.href = '../quadro_chaves_emprestadas.php';
        }
    }).then(function() {
        window.location.href = '../quadro_chaves_emprestadas.php';
    });
    </script>";
        
    }

?>

