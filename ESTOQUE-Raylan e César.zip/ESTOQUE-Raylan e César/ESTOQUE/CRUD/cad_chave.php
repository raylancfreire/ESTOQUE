<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    
</body>
</html>
<?php
    require('../conn.php');

    $numero_chave = $_POST['numero_chave'];
    $sala_chave = $_POST['sala_chave'];
    $status_chave = $_POST['status_chave'];

    if(empty($numero_chave) || empty($sala_chave) || empty($status_chave)){
        echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Valores vazios',
            text: 'Os valores não podem ser vazios.',
            confirmButtonText: 'OK',
            onClose: function() {
                window.location.href = '../cadastro_chave.php';
            }
        }).then(function() {
            window.location.href = '../cadastro_chave.php';
        });
        </script>";
    } else {
        // Verificar se a chave já está cadastrada
        $verifica_chave = $pdo->prepare("SELECT * FROM chaves WHERE numero_chave = :numero_chave");
        $verifica_chave->bindValue(':numero_chave', $numero_chave);
        $verifica_chave->execute();
        $registro_existente = $verifica_chave->fetch(PDO::FETCH_ASSOC);

        if ($registro_existente) {
            echo "<script>
            Swal.fire({
                icon: 'warning',
                title: 'Chave duplicada',
                text: 'Esta chave já está cadastrada.',
                confirmButtonText: 'OK',
                onClose: function() {
                    window.location.href = 'cadastro_chave.php';
                }
            }).then(function() {
                window.location.href = 'cadastro_chave.php';
            });
            </script>";
        } else {
            $cad_item = $pdo->prepare("INSERT INTO chaves(numero_chave, sala_chave, status_chave) 
            VALUES(:numero_chave, :sala_chave, :status_chave)");
            $cad_item->execute(array(
                ':numero_chave'=> $numero_chave,
                ':sala_chave'=> $sala_chave,
                ':status_chave'=> $status_chave
            ));

            if ($cad_item->rowCount() > 0) {
                echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Cadastro de Chave',
                    text: 'Chave cadastrada com sucesso!',
                    confirmButtonText: 'OK',
                    onClose: function() {
                        window.location.href = 'cadastrar_chave.php';
                    }
                }).then(function() {
                    window.location.href = 'cadastro_chave.php';
                });
                </script>";
            } else {
                echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Erro no cadastro',
                    text: 'Ocorreu um erro ao cadastrar a chave.',
                    confirmButtonText: 'OK',
                    onClose: function() {
                        window.location.href = 'cadastro_chave.php';
                    }
                }).then(function() {
                    window.location.href = 'cadastro_chave.php';
                });
                </script>";
            }
        }
    }
?>
