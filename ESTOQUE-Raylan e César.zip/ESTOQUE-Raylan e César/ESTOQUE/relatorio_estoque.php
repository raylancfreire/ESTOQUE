<!DOCTYPE HTML>
<html lang="pt-br">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>RELATÓRIOS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/table.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <?php
    require("protected.php");
    require("conn.php");

    $tabela = $pdo->prepare("SELECT id_item, nome_item, qtd_item, cat_item, local_item, data_item
    FROM itens_tb;");
    $tabela->execute();
    $rowTabela = $tabela->fetchAll();

    $search = isset($_POST['search']) ? $_POST['search'] : '';

    if (!empty($search)) {
        $tabela = $pdo->prepare("SELECT id_item, nome_item, qtd_item, cat_item, local_item, data_item
        FROM itens_tb
        WHERE nome_item LIKE :search
        OR cat_item LIKE :search
        OR local_item LIKE :search
        OR data_item LIKE :search;");
        $tabela->bindValue(':search', '%' . $search . '%');
        $tabela->execute();
        $rowTabela = $tabela->fetchAll();

        if (empty($rowTabela)) {
            echo "<script>
            Swal.fire({
                icon: 'warning',
                title: 'Nenhum item encontrado',
                text: 'Não foram encontrados itens correspondentes à sua pesquisa.',
                confirmButtonText: 'OK'
            });
            </script>";
        }
    }
    ?>

    <div class="container">
        <br>
        <br>
        <h1 style="text-align:center;">RELATÓRIO ESTOQUE</h1>
        <a href="grafico_estoque.php" class="btn btn-secondary btn-lg float-start">GRÁFICO</a>
        <a href="PDF/estoque_pdf.php" style="margin-left: 10px; margin-top: 5px;" class="btn btn-success btn-export" onclick="exibirPopup('Sucesso!', 'Tabela Exportada!', 'success', 'OK')">BAIXAR PDF</a>
        <a href="menu_relatorio.php" class="btn btn-secondary btn-lg float-end">MENU</a>
        <br>
        <br>
        <br>    
        <form method="POST" action="">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Pesquisar" name="search">
                <button class="btn btn-primary" type="submit">Buscar</button>
            </div>
        </form>
        <?php if (!empty($rowTabela)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">ID ITEM</th>
                        <th scope="col">NOME DO ITEM</th>
                        <th scope="col">QUANTIDADE</th>
                        <th scope="col">CATEGORIA</th>
                        <th scope="col">LOCAL</th>
                        <th scope="col">DATA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rowTabela as $linha): ?>
                        <tr>
                            <th scope="row"><?php echo $linha['id_item']; ?></th>
                            <td><?php echo $linha['nome_item']; ?></td>
                            <td><?php echo $linha['qtd_item']; ?></td>
                            <td><?php echo $linha['cat_item']; ?></td>
                            <td><?php echo $linha['local_item']; ?></td>
                            <td><?php echo $linha['data_item']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script>
        function exibirPopup(title, text, icon, buttonText) {
            Swal.fire({
                title: title,
                text: text,
                icon: icon,
                confirmButtonText: buttonText
            });
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>
