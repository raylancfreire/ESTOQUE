<?php
require("conn.php");
require("protected.php");
?>


<!DOCTYPE HTML>
<html lang="pt-br">
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <title>MENU</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link rel="stylesheet" href="CSS/menu2.css">
    </head>
    <body>
        <br>
        <br>
        <h1 style="text-align:center;">RELATÓRIOS</h1>
        <?php if($tipoUsuario === 'ADMIN') : ?>
                <a href="menu.php" class="btn btn-secondary btn-lg float-end">MENU</a>
                <?php elseif($tipoUsuario === 'FUNCIONARIO') : ?>
                    <a href="menu_funcionario.php" class="btn btn-secondary btn-lg float-end">MENU</a>
                    <?php elseif($tipoUsuario === 'INSPETOR') : ?>
                        <a href="menu_inspetor.php" class="btn btn-secondary btn-lg float-end">MENU</a>
                        <?php endif; ?>
        <br>
        <br>
        <br>
        <div class = container>
            <br>
            <br><br><br><br><br><br><br><br><br><br>
        <div class="container1">
            <div class="elemento1">
                <a href= "relatorio_estoque.php" class="botao1">ESTOQUE</a>
            </div>
            <div class="elemento2">
                <a href= "relatorios.php" class="botao1">SAÍDAS DE ITENS</a>
            </div>
        </div>
        </div>
        <script>
    </body>
</html>