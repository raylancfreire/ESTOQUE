<!DOCTYPE html>
<html>
<head>
    <title>Gráfico</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="CSS/grafico.css">
    <style>
        
    </style>
</head>
<body>
    <a href="relatorios.php" class="botao"
    style="width: 200px; 
        height: 90px; 
        border: solid black 2px;
        border-radius: 1px;
        text-decoration-line: none;
        background-color: rgb(166, 210, 248);"
    >VOLTAR</a>
    <button onclick="toggleChartType()">Alternar Gráfico</button>
    <canvas id="chart"></canvas>

    <script>
        // Dados do gráfico
        var data = {
            labels: [], // Nomes dos itens
            datasets: [{
                label: 'Quantidade',
                data: [], // Valores das quantidades
                backgroundColor: 'rgba(104, 171, 233, 1)', // Cor de fundo das barras ou fatias
                borderColor: 'rgba(35, 34, 109, 1)', // Cor da borda das barras ou fatias
                borderWidth: 3 // Largura da borda das barras ou fatias
            }]
        };

        // Configurações do gráfico
        var options = {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value;
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        title: function(context) {
                            return context[0].label;
                        },
                        label: function(context) {
                            return context.dataset.label + ': ' + context.formattedValue;
                        }
                    }
                }
            }
        };

        // Criação do gráfico
        var ctx = document.getElementById('chart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: options
        });

        // Função para adicionar os dados ao gráfico
        function addData(label, value) {
            chart.data.labels.push(label);
            chart.data.datasets[0].data.push(value);
            chart.update();
        }

        // Dados dos itens
        var items = <?php
            require("conn.php");
            $itens = $pdo->query("SELECT nome_item, quantidade FROM relatorios_tb")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($itens);
        ?>;

        // Adição dos dados ao gráfico
        for (var i = 0; i < items.length; i++) {
            addData(items[i].nome_item, items[i].quantidade);
        }

        // Função para alternar entre os tipos de gráfico
        function toggleChartType() {
            if (chart.config.type === 'bar') {
                chart.config.type = 'pie';
                chart.config.options.scales.y.display = false;
                chart.config.options.plugins.tooltip.enabled = false;
                chart.update();
            } else {
                chart.config.type = 'bar';
                chart.config.options.scales.y.display = true;
                chart.config.options.plugins.tooltip.enabled = true;
                chart.update();
            }
        }
    </script>
</body>
</html>

