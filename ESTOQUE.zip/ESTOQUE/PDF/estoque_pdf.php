<?php
require("../conn.php");
require("../protected.php");
require("biblioteca/fpdf.php");

// Dados da tabela
$tabela = $pdo->prepare("SELECT id_item, nome_item, qtd_item, cat_item, data_item FROM itens_tb");
$tabela->execute();
$rowTabela = $tabela->fetchAll(PDO::FETCH_ASSOC);

// Cria uma instância do objeto FPDF
$pdf = new FPDF();

// Define o título do documento
$pdf->SetTitle('Estoque');

// Adiciona uma página ao PDF
$pdf->AddPage();

// Define a fonte padrão
$pdf->SetFont('Arial', 'B', 14);

// Define a largura das colunas da tabela
$colWidth = 35;
$pdf->SetFillColor(200, 200, 200);
$pdf->Cell($colWidth, 10, 'ID Item', 1, 0, 'C', true);
$pdf->Cell($colWidth, 10, 'Nome', 1, 0, 'C', true);
$pdf->Cell($colWidth, 10, 'Quantidade', 1, 0, 'C', true);
$pdf->Cell($colWidth, 10, 'Categoria', 1, 0, 'C', true);
$pdf->Cell($colWidth + 10, 10, 'Data e Hora', 1, 1, 'C', true);

// Define a fonte para os dados da tabela
$pdf->SetFont('Arial', '', 12);

// Percorre os dados da tabela
foreach ($rowTabela as $linha) {
    $idItem = utf8_decode($linha['id_item']);
    $nome = utf8_decode($linha['nome_item']);
    $qtdItem = utf8_decode($linha['qtd_item']);
    $categoria = utf8_decode($linha['cat_item']);
    $data = utf8_decode($linha['data_item']);

    // Verifica se a célula excede a largura da página
    if ($pdf->GetX() + $colWidth > $pdf->GetPageWidth()) {
        $pdf->AddPage();
        $pdf->Cell($colWidth, 10, 'ID Item', 1, 0, 'C', true);
        $pdf->Cell($colWidth, 10, 'Nome', 1, 0, 'C', true);
        $pdf->Cell($colWidth, 10, 'Quantidade', 1, 0, 'C', true);
        $pdf->Cell($colWidth, 10, 'Categoria', 1, 0, 'C', true);
        $pdf->Cell($colWidth + 10, 10, 'Data', 1, 1, 'C', true);
    }

    // Adiciona uma célula para cada campo
    $pdf->Cell($colWidth, 10, $idItem, 1, 0, 'C');
    $pdf->Cell($colWidth, 10, $nome, 1, 0, 'C');
    $pdf->Cell($colWidth, 10, $qtdItem, 1, 0, 'C');
    $pdf->Cell($colWidth, 10, $categoria, 1, 0, 'C');
    $pdf->Cell($colWidth + 10, 10, $data, 1, 1, 'C');
}

// Define o nome do arquivo com a data de download
$fileName = 'Estoque' . date('Y-m-d') . '.pdf';

// Define o cabeçalho para download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $fileName . '"');

// Envia o PDF para o navegador
$pdf->Output('D', $fileName);
